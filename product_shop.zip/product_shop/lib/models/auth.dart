enum AuthMode { 
  Signup, Login 
  }
